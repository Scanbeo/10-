
function searchEmoji() {
    const input = document.getElementById('emojiInput').value;
    const selectedGroup = document.getElementById('emojiGroup').value;
    const api_url = `https://api.api-ninjas.com/v1/emoji?name=${input}&group=${selectedGroup}`;

    fetch(api_url, {
        headers: {
            'X-Api-Key': 'WTKqluCXWsnIyBMAFSH65A==mckMHYtmlkxtw4Gd'
        }
    })
    .then(response => response.json())
    .then(data => {
        const emojiResultsDiv = document.getElementById('emojiResults');
        emojiResultsDiv.innerHTML = ''; // Clear previous results

        if (data.length === 0) {
            emojiResultsDiv.innerHTML = 'No emoji found';
            return;
        }

        data.forEach(emoji => {
            const emojiElement = document.createElement('div');
            emojiElement.innerHTML = `
                <p>Name: ${emoji.name}</p>
                <p>Code: ${emoji.code}</p>
                <img src="${emoji.image}" alt="${emoji.character}">
                <p>Character: ${emoji.character}</p>
                <p>Group: ${emoji.group}</p>
                <p>Subgroup: ${emoji.subgroup}</p>
            `;
            emojiResultsDiv.appendChild(emojiElement);
        });
    })
    .catch(error => console.error('Error fetching emoji:', error));
}
